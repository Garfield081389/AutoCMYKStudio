package com.example.autocmyk

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import java.io.InputStream
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin

class MainActivity : ComponentActivity() {
    private var source: Bitmap? = null
    private lateinit var status: TextView
    private lateinit var lpiInput: EditText

    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            try {
                contentResolver.openInputStream(uri)?.use { stream ->
                    source = android.graphics.BitmapFactory.decodeStream(stream)
                }
                status.text = if (source != null) "Artwork loaded: ${source!!.width} × ${source!!.height}" else "Could not open image"
            } catch (e: Exception) { status.text = "Could not open image" }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 28)
            setBackgroundColor(Color.rgb(16, 24, 32))
        }
        fun text(value: String, size: Float, color: Int = Color.WHITE) = TextView(this).apply {
            this.text = value; textSize = size; setTextColor(color); setPadding(0, 10, 0, 10)
        }
        root.addView(text("AUTO CMYK STUDIO", 25f, Color.rgb(101, 214, 166)))
        root.addView(text("Silkscreen color separation", 16f))
        status = text("No artwork selected", 14f, Color.LTGRAY)
        root.addView(status)
        val choose = Button(this).apply { text = "IMPORT ARTWORK"; setOnClickListener { picker.launch("image/*") } }
        root.addView(choose, buttonParams())
        root.addView(text("Halftone LPI (10–150)", 14f))
        lpiInput = EditText(this).apply { setText("45"); setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); setSingleLine(true) }
        root.addView(lpiInput, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val generate = Button(this).apply { text = "GENERATE CMYK FILMS"; setOnClickListener { generateFilms() } }
        root.addView(generate, buttonParams())
        root.addView(text("Creates four black-and-white halftone PNG plates (C, M, Y, K). Results are saved in Pictures/AutoCMYKStudio.", 13f, Color.LTGRAY))
        root.addView(text("Note: RGB-to-CMYK conversion is approximate. Test films before production printing.", 12f, Color.rgb(255, 205, 110)))
        setContentView(root)
    }

    private fun buttonParams() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = 12 }

    private fun generateFilms() {
        val bmp = source
        if (bmp == null) { Toast.makeText(this, "Import an image first", Toast.LENGTH_SHORT).show(); return }
        val lpi = lpiInput.text.toString().toIntOrNull()?.coerceIn(10, 150) ?: 45
        val w = bmp.width.coerceAtMost(2400)
        val h = (bmp.height.toLong() * w / bmp.width).toInt().coerceAtLeast(1)
        val scaled = Bitmap.createScaledBitmap(bmp, w, h, true)
        val names = listOf("Cyan" to 15.0, "Magenta" to 75.0, "Yellow" to 0.0, "Black" to 45.0)
        try {
            for ((index, item) in names.withIndex()) {
                val plate = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                val angle = item.second * PI / 180.0
                val freq = lpi / 45.0
                for (y in 0 until h) for (x in 0 until w) {
                    val pixel = scaled.getPixel(x, y)
                    val r = Color.red(pixel) / 255.0
                    val g = Color.green(pixel) / 255.0
                    val b = Color.blue(pixel) / 255.0
                    val k = 1.0 - maxOf(r, g, b)
                    val c = if (k >= 0.999) 0.0 else (1.0 - r - k) / (1.0 - k)
                    val m = if (k >= 0.999) 0.0 else (1.0 - g - k) / (1.0 - k)
                    val yy = if (k >= 0.999) 0.0 else (1.0 - b - k) / (1.0 - k)
                    val ink = listOf(c, m, yy, k)[index].coerceIn(0.0, 1.0)
                    val pattern = (x * cos(angle) + y * sin(angle)) * freq * 0.12
                    val dot = (0.5 + 0.5 * sin(pattern * 2.0 * PI)).coerceIn(0.0, 1.0)
                    val black = if (ink > dot) 0 else 255
                    plate.setPixel(x, y, Color.rgb(black, black, black))
                }
                saveBitmap(plate, "${item.first}_film.png")
                plate.recycle()
            }
            Toast.makeText(this, "4 film PNGs saved in Pictures/AutoCMYKStudio", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Export failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun saveBitmap(bitmap: Bitmap, filename: String) {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, filename)
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AutoCMYKStudio")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: error("Could not create output file")
        contentResolver.openOutputStream(uri)?.use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) } ?: error("Could not save output")
    }
}
